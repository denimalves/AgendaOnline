<template>
  <q-table title="agendamentos" :rows="agendamentos" :columns="columns" row-key="id">
    <template v-slot:top>
      <router-link :to="{ name: 'home' }">
        <q-avatar size="100px" class="q-mb-sm">
          <img src="../assets/logovictoriasmobile.png" />
        </q-avatar>
      </router-link>

      <span class="text-h5">Agendamentos</span>

      <q-space />
      <q-btn color="primary" label="Novo" :to="{ name: 'agendarEvento' }" />
      <q-btn label="Exportar PDF" color="primary" @click="$emit('exportar-pdf')" />
    </template>

    <template v-slot:body-cell-acoes="props">
      <q-td :props="props" class="q-gutter-sm">
        <q-btn icon="edit" color="info" dense size="sm" @click="$emit('editar', props.row.id)" />
        <q-btn
          icon="delete"
          color="negative"
          dense
          size="sm"
          @click="$emit('excluir', props.row.id)"
        />
      </q-td>
    </template>
  </q-table>
</template>

<script setup>
defineProps(['agendamentos', 'columns'])
defineEmits(['editar', 'excluir', 'exportar-pdf'])
</script>
