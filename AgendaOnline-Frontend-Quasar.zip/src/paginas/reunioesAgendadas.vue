<template>
  <div>
    <!-- Tabela oculta para exportar PDF -->
    <div id="relatorio-pdf" style="display: none">
      <table style="width: 100%; border-collapse: collapse" border="1">
        <thead>
          <tr>
            <th style="padding: 8px">#</th>
            <th style="padding: 8px">Data</th>
            <th style="padding: 8px">Evento</th>
          </tr>
        </thead>
        <tbody></tbody>
      </table>
    </div>

    <div class="q-pa-md">
      <AgendamentosForm
        :agendamentos="agendamentos"
        :columns="columns"
        @editar="handleEditarAgenda"
        @excluir="handleExcluirAgenda"
        @exportar-pdf="gerarPDF"
      />
    </div>
  </div>
</template>

<script setup>
import { onMounted, ref } from 'vue'
import agendaServicos from 'src/servicos/agenda.js'
import { useQuasar } from 'quasar'
import { useRouter } from 'vue-router'
import html2pdf from 'html2pdf.js'
import AgendamentosForm from 'src/componentes/agendamentosForm.vue'

const agendamentos = ref([])
const { listar, excluir } = agendaServicos()
const columns = [
  { name: 'id', field: 'id', label: 'ID', sortable: true, align: 'center' },
  { name: 'data', field: 'data', label: 'DATA', sortable: true, align: 'center' },
  { name: 'evento', field: 'evento', label: 'EVENTO', sortable: true, align: 'center' },
  { name: 'acoes', field: 'acoes', label: 'Ações', align: 'center' },
]

const $q = useQuasar()
const router = useRouter()

onMounted(() => {
  getAgenda()
})

const getAgenda = async () => {
  try {
    agendamentos.value = await listar()
  } catch (error) {
    console.error('Erro ao buscar agendamentos:', error)
  }
}

const handleExcluirAgenda = async (id) => {
  try {
    $q.dialog({
      title: 'Excluir Agendamento',
      message: 'Tem certeza que deseja remover este agendamento?',
      cancel: true,
      persistent: true,
    }).onOk(async () => {
      await excluir(id)
      $q.notify({ message: 'Removido com sucesso', icon: 'check', color: 'positive' })
      await getAgenda()
    })
  } catch (error) {
    alert(error)
  }
}

const handleEditarAgenda = (id) => {
  router.push({ name: 'agendarEvento', params: { id } })
}

const gerarPDF = () => {
  const elemento = document.getElementById('relatorio-pdf')
  if (!elemento) return

  const agendamentosOrdenados = [...agendamentos.value].sort((a, b) => {
    const regex = /(\d{2})\/(\d{2})\/(\d{4})\s+das\s+(\d{2}):(\d{2})h/
    const parse = (str) => {
      const m = str.match(regex)
      return m ? new Date(`${m[3]}-${m[2]}-${m[1]}T${m[4]}:${m[5]}:00`) : new Date(0)
    }
    return parse(a.data) - parse(b.data)
  })

  const tbody = elemento.querySelector('tbody')
  tbody.innerHTML = ''
  agendamentosOrdenados.forEach((ag, i) => {
    const row = document.createElement('tr')
    row.innerHTML = `<td>${i + 1}</td><td>${ag.data}</td><td>${ag.evento}</td>`
    tbody.appendChild(row)
  })

  const titulo = document.createElement('h5')
  titulo.textContent = 'Relatório de Agendamentos'
  titulo.style.textAlign = 'center'
  titulo.style.marginBottom = '10px'
  titulo.id = 'titulo-relatorio'

  const dataAtual = new Date().toLocaleString('pt-BR')
  const dataElemento = document.createElement('p')
  dataElemento.textContent = `Gerado em: ${dataAtual}`
  dataElemento.style.textAlign = 'right'
  dataElemento.style.marginBottom = '20px'
  dataElemento.id = 'data-relatorio'

  elemento.insertBefore(titulo, elemento.firstChild)
  elemento.insertBefore(dataElemento, titulo.nextSibling)
  elemento.style.display = 'block'

  const opcoes = {
    margin: 10,
    filename: 'relatorio-agendamentos.pdf',
    image: { type: 'jpeg', quality: 0.98 },
    html2canvas: { scale: 2 },
    jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' },
  }

  html2pdf()
    .set(opcoes)
    .from(elemento)
    .save()
    .then(() => {
      elemento.style.display = 'none'
      const tituloRemover = document.getElementById('titulo-relatorio')
      if (tituloRemover) tituloRemover.remove()
    })
}
</script>
