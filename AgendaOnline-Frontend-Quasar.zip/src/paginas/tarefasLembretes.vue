<template>
  <q-page class="q-pa-md row justify-center">
    <q-card class="q-pa-sm" style="width: 400px" bordered>
      <!-- <div><h5 align="center">PÁGINA EM MANUTENÇÃO</h5></div> -->
      <q-card-section class="text-h5 q-mb-md flex flex-center" elevated>
        <div>Tarefa Atual</div>
        <div>{{ dataHoje }}</div>
      </q-card-section>
      <q-card-section class="q-gutter-sm">
        <q-input
          v-model="tarefaAtual.titulo"
          name="titulo"
          type="text"
          placeholder="Titulo"
          dense
        />
        <q-input
          v-model="tarefaAtual.descricao"
          name="descricao"
          type="text"
          placeholder="Descricao"
          dense
        />
        <q-select
          v-model="tarefaAtual.status"
          :options="['Pendente', 'Concluída']"
          label="Status"
          dense
          emit-value
          map-options
        />
      </q-card-section>
      <q-card-actions align="center">
        <q-btn flat icon="cancel" label="" color="primary" @click="limparFormulario" />
        <q-btn
          name="salvar"
          color="primary"
          icon="save"
          :disable="!tarefaAtual.titulo"
          @click="salvarTarefa"
        >
        </q-btn>
        <q-btn
          name="excluir"
          icon="delete"
          color="negative"
          :disable="!tarefaAtual.titulo"
          @click="excluirTarefa(tarefaAtual.id)"
        ></q-btn>
      </q-card-actions>
    </q-card>
    <q-card-section class="q-gutter-sm">
      <q-table title="Histórico de Tarefas Diárias" :rows="tarefas" :columns="columns" row-key="id">
        <template v-slot:body-cell-acoes="props">
          <q-td :props="props" class="q-gutter-sm">
            <q-btn
              icon="visibility"
              label="Selecionar"
              color="primary"
              dense
              size="sm"
              @click="preencherFormulario(props.row)"
            />
          </q-td>
        </template>
      </q-table>
    </q-card-section>
  </q-page>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import agendaTarefas from 'src/servicos/tarefas'
import { useQuasar } from 'quasar'

const { listar, inserir, atualizar, excluir } = agendaTarefas()
const tarefas = ref([])
const tarefaAtual = ref({ titulo: '', descricao: '', status: 'Pendente' })
const $q = useQuasar()

const columns = [
  { name: 'titulo', label: 'Título', align: 'left', field: 'titulo' },
  { name: 'descricao', label: 'Descrição', align: 'left', field: 'descricao' },
  { name: 'status', label: 'Status', align: 'left', field: 'status' },
  { name: 'acoes', label: 'Ações', align: 'center' },
]

const dataHoje = ref(
  new Date().toLocaleDateString('pt-BR', {
    weekday: 'long',
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
  }),
)

async function carregarTarefas() {
  tarefas.value = await listar()
}

function preencherFormulario(tarefa) {
  tarefaAtual.value = { ...tarefa }
}

function limparFormulario() {
  tarefaAtual.value = { titulo: '', descricao: '', status: 'Pendente' }
}

async function salvarTarefa() {
  if (tarefaAtual.value.id) {
    await atualizar(tarefaAtual.value)
  } else {
    await inserir(tarefaAtual.value)
  }
  $q.notify({
    type: 'positive',
    message: 'Tarefa Salva com sucesso',
  })
  limparFormulario()
  carregarTarefas()
}

async function excluirTarefa(id) {
  //mensagem para confirmar a exclusao
  $q.dialog({
    title: 'Confirmar',
    message: 'Tem certeza que deseja excluir a tarefa?',
    cancel: true,
    persistente: true,
  })
    .onOk(async () => {
      //se usuario confirmar
      await excluir(id)
      limparFormulario()
      carregarTarefas()
      $q.notify({
        type: 'positive',
        message: 'Tarefa excluida com sucesso?',
      })
    })
    .onCancel(() => {
      //se usuario cancelar
      $q.notify({
        type: 'info',
        message: 'Cancelado pelo usuario',
      })
    })
}

onMounted(() => {
  carregarTarefas()
})
</script>
