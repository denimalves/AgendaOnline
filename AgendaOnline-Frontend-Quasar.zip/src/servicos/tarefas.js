import useApi from 'src/composables/UseApi.js'

export default function agendaTarefas() {
  const { listar, inserir, atualizar, excluir, getById } = useApi('tarefas')
  return { listar, inserir, atualizar, excluir, getById }
}
